Config = {}

--Possible: ESX, QBCORE
Config.FrameWork = "QBCORE"